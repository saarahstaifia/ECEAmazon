<?php
  require_once("../Première version ECEAmazon/hearder.php"); 

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title> Catégories</title>
     <link rel="stylesheet" href="designcategories.css" />
</head>
<body>

	

<div id="colonne1">	  
<!-- <div id="colonne1">-->
	<div id="ligne1"><div id="image"><a href="http://localhost/Première version ECEAmazon/livre.php"><img src="livres_accueil.jpg" height="200" width="200" border="thick double black"> </a></div></div>
  
    <div id="ligne2"><div id="image"><a href="http://localhost/Première version ECEAmazon/musique.php"><img src="musique_accueil.jpg" height="200" width="200"></a></div></div>
 
</div>

<div id="colonne2">
<!--<div id="colonne2">-->
	<div id="ligne1"><div id="image"><a href="http://localhost/Première version ECEAmazon/vetement.php"><img src="vetements_accueil.jpg" height="200" width="200"> </a></div></div>
 
    <div id="ligne2"><div id="image"><a href="http://localhost/Première version ECEAmazon/sport_loisir.php"><img src="loisirs_accueil.JPG" height="200" width="200"> </a></div> </div>
 
</div>








</body>
</html>