<?php 
  
require_once("../Première version ECEAmazon/hearder.php"); 

?>

<!DOCTYPE html>
<html>
<head>
	<title>Retours et remboursements</title>
	<meta charset="utf-8">
	<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">



</style>
</head>
<body>
	

<!-- Texte -->
	   <h1> Retours et remboursements </h1>

<p>Mes retours</p>
<br><br>
<p>Mes remboursements effectués<p>



	 

</body>
</html>