<?php

$pseudo= isset($_POST["pseudo"])? $_POST["pseudo"] : "";
$mdp = isset($_POST["mdp"])? $_POST["mdp"] : "";


if (isset($_POST["Login"]))
 {
	if ($pseudo&&$mdp)
	{
		if($pseudo =='admin' && $mdp=='admin'){
			header('Location:administ.html');
		}
		else{
			?>
			<script type="text/javascript">alert("Erreur de connexion, veuillez réessayer.")</script>
			<?php
		}
}
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Administration</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="admin.css" />
	<script type="text/javascript" src="admin.js"> </script>
</head>
<body>

<h1><div id="colonne"><a href="accueil.html" ><img src="logo_ece_amazon1.png" alt="Logo de ECE AMAZON" height=" 150" width="200"></a></div></h1>

	<br><br><br><br><br><br><br><br>
	<div id="nav">      
	  <a href="categories.html">Categories</a>        
	  <a href="ventes_flash.html">Ventes Flash</a>        
	  <a href="vendre.html">Vendre</a>       
	  <a href="votre_compte.html">Votre Compte</a>
	  <a href="panier.html"><img src="panier.png" height=" 50" width="50"></a>  
	  <a href="aide.html">Aide</a>
	   </div> 

	   <!-- Informations d'authentification-->
 
	   	<div id="container">
	   <form action="administration.php" method="post"> 
	    <h1> Connexion </h1>
	   <table> 
	          <tr>   
	                <td>Pseudo:</td>    
	                <td><input type="text" placeholder="Entrez votre pseudo" name="pseudo"/></td>               
	          </tr>    
	          <tr>  <td>Mot de passe:</td>    
	                <td><input type="password"placeholder="Entrez votre mot de passe" name="mdp"/></td>   
	          </tr>               
	          <tr>                      
	          	    <td colspan="2" align="center">                          
	          	    <input type="submit" name="Login">                      
	          	    </td>                 
	          </tr>  
	   </table>  
	   </form> 
	</div>
</body> 
</html> 

</body>
</html>

