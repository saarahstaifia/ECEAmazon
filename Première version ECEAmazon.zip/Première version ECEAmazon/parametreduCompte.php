<?php 
require_once("../Première version ECEAmazon/hearder.php"); 

  
?>

<!DOCTYPE html>
<html>
<head>
	<title>Parametres du compte</title>
	<meta charset="utf-8">
	<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">



</style>
</head>
<body>
	

<!-- Texte -->
	   <h1> Parametres du compte </h1>

<p>Connexion et parametres de securite</p>
<br><br>
<p>Mes commandes<p>
<br><br>
<p>Adresses<p>
<br><br>
<p>Options de paiement<p>


	  

</body>
</html>