<?php

if (isset($_POST['submit']))

	{
		$mail_acheteur=($_POST['mail_acheteur']);
		$nom_acheteur=($_POST['nom_acheteur']);
        $prenom_acheteur=($_POST['prenom_acheteur']);
        $adresse_acheteur=($_POST['adresse_acheteur']);
        $motdepasse_acheteur=($_POST['motdepasse_acheteur']);
        if ($mail_acheteur&&$nom_acheteur&&$prenom_acheteur&&$adresse_acheteur&&$motdepasse_acheteur)
        {
        	$database = "gestion";
 	        $db_handle = mysqli_connect('localhost', 'root', '');
            $db_found = mysqli_select_db($db_handle, $database);
            if ($db_found)
            {

               $query="INSERT INTO acheteur(mail_acheteur,nom_acheteur,prenom_acheteur,adresse_acheteur,motdepasse_acheteur) VALUES('$mail_acheteur','$nom_acheteur','$prenom_acheteur','$adresse_acheteur','$motdepasse_acheteur')"; 
               $res=mysqli_query($db_handle,$query);
               mysqli_close($db_handle);
             }
        }
    }
?>



      
              

<!DOCTYPE html> 
<html> 
<head> 
       <title>Nouveau client</title>  
       <meta charset="utf-8">  
       <link rel="stylesheet" href="creercompte.css" />
    
</head> 
<body>   

<!-- Les différents onglets -->
<h1 class="logo"><img src="logo_ece_amazon1.png" alt="Logo de ECE AMAZON" height=" 150" width="200"></h1>
 <div id="colonne2">
    	    <form action="/search" id="searchthis" method="Post">
    	        <input id="search" name="q" type="text" placeholder="" />
    	        <input id="search-btn" type="submit" value="Rechercher" />
    	    </form>
    	</div>
	<br><br><br><br><br><br><br><br>
	<div id="nav">      
	  <a href="categories.html">Categories</a>        
	  <a href="ventes_flash.html">Ventes Flash</a>        
	  <a href="vendre.html">Vendre</a>       
	  <a href="votre_compte.html">Votre Compte</a>
	  <a href="panier.html"><img src="panier.png" height=" 50" width="50"></a>  
	  <a href="aide.html">Aide</a>
	   </div> 
	   <!-- barre de recherche -->


<!-- Administrateur, accessible en haut à gauche de l'écran -->

	   <div id="admin"><a href="admin.html"> Administration </a>
	   </div>


	<!-- Formulaire de création -->
	        <form method="post" action="creer_compte.php">   
	          <h3>Créez votre compte</h3>  
	           
	                 <table>  
	                 <tr>      
	                 	   	        <td>Adresse Mail:</td>      
	                 	   	        <td><input type="text" name="mail_acheteur"></td>     
	                 	   </tr>   
	                 	   <tr>      
	                 	   	        <td>Nom:</td>      
	                 	   	        <td><input type="text" name="nom_acheteur"></td>     
	                 	   </tr>
	                 	   <tr>      
	                 	   	        <td>Prénom:</td>      
	                 	   	        <td><input type="text" name="prenom_acheteur"></td>     
	                 	   </tr>
	                 	            
	                 	   <tr>      
	                 	   	        <td>Adresse :</td>      
	                 	   	        <td><input type="text" name="adresse_acheteur"></td>     
	                 	   </tr>
	                 	   <tr>      
	                 	   	        <td>Mot de passe :</td>      
	                 	   	        <td><input type="password" name="motdepasse_acheteur"></td>     
	                 	   </tr>
	                 	   
	                 	   <tr>      
	                 	   	        <td colspan="2" align="center"><input type="submit" name="submit" ></td>     
	                 	   </tr>    
	                 </table>   
	            </form>

	          
 
</body> 
</html> 
