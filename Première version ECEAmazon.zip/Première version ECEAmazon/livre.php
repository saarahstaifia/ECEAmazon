<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Livre</title>
	<link rel="stylesheet" type="text/css" href="designaccueil.css">
	<link rel="stylesheet" type="text/css" href="liste_article.css">
    
    
    

</head>
<body>

	<h1>
         <div id="colonne1"><a href="accueil.html"><img src="logo_ece_amazon1.png" alt="Logo de ECE AMAZON" height=" 150" width="200"></a>
         </div>

        <!--création d'une page php nécessaire pour la recherche d'informations à l'aide de la barre de recherche-->
         <div id="colonne2">
            <form action="/search" id="searchthis" method="Post">
                <input id="search" name="q" type="text" placeholder="" />
                <input id="search-btn" type="submit" value="Rechercher" height="400" width="100" />
            </form>
         </div>
         <div id="adm"><a href="admin.html">Administrateur</a></div> 
         <br/><br/><br/><br/>
        <!--Création des multiples éléments tel que catégories ventes flash vendre votre commande-->
         <div id="nav">      
            <a href="categories.html">Categories</a>        
            <a href="ventes_flash.html">Ventes Flash</a>        
            <a href="vendre.html">Vendre</a>       
            <a href="votre_compte.html">Votre Compte</a>
            <a href="aide.html">Aide</a>
            <a href="panier.html"><img src="panier.png" height=" 20" width="100"></a> 
         </div><br/>
    </h1>

<?PHP



	
	$email = "livre";

	$database = "gestion";

	$db_found = new mysqli("localhost","root",  "", $database );


	if ($db_found) {

		$SQL = $db_found->prepare('SELECT * FROM article WHERE Type = ?');
		$SQL->bind_param('s', $email);
		$SQL->execute();

		

		$result = $SQL->get_result();

		if ($result->num_rows > 0) {
			
			while ( $db_field = $result->fetch_assoc() ) {
				$var =$db_field['iD'] ;
				


			    
?>
			
			<form method="post" action="panier.php">
				<div id="ligne1">
				    <div id="colonne11"><?php print $db_field['image'] . "<BR>";?><br/><br/><br/><br/></div>
			        <div id="colonne22"><?php print $db_field['nom'] . "<BR>";?><br/><?php print $db_field['description'] . "<BR>";?></div>
			        
                    <div id="colonne33"><?php print $db_field['prix'] . "<BR>";?>€
                    </div>
                    <div id="colonne44"><a href="<?php echo"panier.php?var=".$var.""?>"> <input type= "button"name="boutton" value="ajouter au panier"></a>
                    </div>


				</div><br/><br/><br/><br/><br/><br/><br/><br/>
			</form>		


<?php
			}



		}
		else {
			print "No records found";
		
		}
		$SQL->close();
		$db_found->close();

	}
	else {
		print "Database NOT Found ";
	}
?>

<!-- Footer -->
<div id="footer">Copyright &copy; 2019 ECE Amazon<br>   
        <a href="mailto:ece_amazon_contact@gmail.com">ece_amazon_contact@gmail.com </a> 
</div>



</body>
</html>

