<?php 

require_once("../Première version ECEAmazon/hearder.php"); 

  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Commandes</title>
	<meta charset="utf-8">
	<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">




</style>
</head>
<body>

<!-- Texte -->
	   <h1> Mes commandes </h1>

<p> Vous pouvez consulter ci-dessous vos commandes</p>

<br><br>
<p>Suivi de mes commandes</p>
<br><br>
<p>Mes retours</p>
<br><br>
<p>Contact</p>
<br><br>



	  

</body>
</html>