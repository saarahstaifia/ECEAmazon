<?php

$article = "";
