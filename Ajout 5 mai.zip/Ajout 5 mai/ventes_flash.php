<?php










?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8'>
	<title>Ventes Flash</title>
</head>
<body>

<h1> Retrouvez ici nos best-sellers de la semaine! </h1>

<h2> Nos meilleures ventes catégorie "Livres" </h2>
<br><br><br><br>

<h2> Nos meilleures ventes catégorie "Musique" </h2>
<br><br><br><br>

<h2> Nos meilleures ventes catégorie "Vêtements" </h2>
<br><br><br><br>

<h2> Nos meilleures ventes catégorie "Sports et Loisirs" </h2>
<br><br><br><br>


</body>
</html>