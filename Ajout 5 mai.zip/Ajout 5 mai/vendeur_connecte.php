<?php
// Code pour pouvoir ajouter des items














?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title> Vendeur Connecté</title>
	<link rel="stylesheet" href="vendeur_connecte.css" />

<script type="text/javascript">
	// pour pouvoir choisir la couleur de sa page

	function couleur()
	{
		var objet1=document.getElementById("saisie");
		var objet2=document.getElementById("div1");
         objet2.style.backgroundColor=objet1.value;

	}

	</script>
	</head>
<body>
		<div id="div1"></div>
	<p> Tapez le nom de la couleur</p>
		<form>
			<input type="text" id="saisie">
			<input type="button" onclick="couleur()" value="Modifier la couleur">
		</form>

		<div id="nom_acheteur" >
			 Bienvenue  


		</div>

</body>
</html>