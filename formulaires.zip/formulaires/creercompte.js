var message=""; 
 
function validate() {     
       testEmpty();     
       validateName();
       validateUsername();     
       validateTelephone();     
       validateBirthday();
       validateAdress();
       validateVille();
       validateDepartement();
       message=""; }//end function 
 
function testEmpty() {    
       if ((document.getElementById("name").value ==='') ||
           (document.getElementById("username").value ==='') ||                 
           (document.getElementById("phone").value ==='') ||         
           (document.getElementById("birthday").value ==='')||
           (document.getElementById("adress").value ==='') ||
           (document.getElementById("ville").value ==='') ||
           (document.getElementById("dpt").value ==='') ||) {         
            alert("Un champ est vide");    
        } 
}//end function 
 
function validateName() {     
       if (document.getElementById("name").value === ''){        
           var messageName1 = "<br/>Le champ Nom est vide.";         
           message += messageName1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 

function validateUsername() {     
       if (document.getElementById("username").value === ''){        
           var messageUsername1 = "<br/>Le champ Prénom est vide.";         
           message += messageUsername1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 
 
function validateTelephone() {     
       if (document.getElementById("phone").value === ''){         
           var messageTel1 = "<br/>Le champ Telephone est vide.";         
           message += messageTel1;         
           document.getElementById("errordiv").innerHTML = message;  
            }//end if     
       if ((document.getElementById("phone").value).match(/[a-z]/i)){         
            var messageTel2 = "<br/>Le champ Telephone ne doit pas avoir des lettres.";         
            message += messageTel2;         
            document.getElementById("errordiv").innerHTML = message;     
            }//end if     
       if ((document.getElementById("phone").value).length != 10){         
            var messageTel3 = "<br/>Le champ Telephone doit avoir 10 chiffres.";         
            message += messageTel3;         
            document.getElementById("errordiv").innerHTML = message;     
            }//end if }//end function 
 
function validateBirthday() {     
       if (document.getElementById("birthday").value === ''){        
           var messageDate1 = "<br/>Le champ Date de naissance est vide.";         
           message += messageDate1;         
           document.getElementById("errordiv").innerHTML = message;     
           }//end if 
}//end function 

function validateAdress() {     
       if (document.getElementById("adress").value === ''){        
           var messageAdress1 = "<br/>Le champ Adresse est vide.";         
           message += messageAdress1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 

function validateVile() {     
       if (document.getElementById("ville").value === ''){        
           var messageUsername1 = "<br/>Le champ Ville est vide.";         
           message += messageUsername1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 

function validateDepartement() {     
       if (document.getElementById("dpt").value === ''){        
           var messageUsername1 = "<br/>Le champ Département est vide.";         
           message += messageUsername1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 


 