<?php 
  
?>

<!DOCTYPE html>
<html>
<head>
	<title>Options de paiement</title>
	<meta charset="utf-8">
	<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">

h1
{ 

font-style: bold;
color:#49868F;
 }

 #footer 
{ 

background-color:#49868F;
position: absolute;
font-weight: bold;
bottom:0;
width:100%;
padding-top:40px;
height:50px; 
}

</style>
</head>
<body>
	

<!-- Texte -->
	   <h1> Options de paiement </h1>

<p>Vos cartes de paiement</p>
<br><br>
<p>Vos cheques cadeaux<p>
<br><br>
<p>Modifier la methode de paiement pour une commande en cours<p>
<br><br>



	   <!-- Footer -->
<div id="footer">Copyright &copy; 2019 ECE Amazon<br>   
 <a href="mailto:ece_amazon_contact@gmail.com">ece_amazon_contact@gmail.com </a> 
</div> 

</body>
</html>