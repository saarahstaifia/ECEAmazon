CREATE TABLE article 
(

	ID int PRIMARY KEY NOT NULL,
	Nom varchar (255) NOT NULL,
	Image varchar (255) NOT NULL,
	Description varchar (255) NOT NULL,
	Prix int NOT NULL,
	Type varchar (255) NOT NULL
);