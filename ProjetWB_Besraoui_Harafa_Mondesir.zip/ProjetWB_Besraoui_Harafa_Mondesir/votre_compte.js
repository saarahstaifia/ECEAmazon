var message=""; 
 
function validate() {     
       testEmpty();     
       validateAdressmail();
       validateMotdepass();     
       message=""; }//end function 
 
function testEmpty() {    
       if ((document.getElementById("mail").value ==='') ||
           (document.getElementById("passw").value ==='') ||) {         
            alert("Un champ est vide");    
        } 
}//end function 
 
function validateAdressmail() {     
       if (document.getElementById("mail").value === ''){        
           var messageMail1 = "<br/>Le champ adresse mail est vide.";         
           message += messageMail1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 

function validateMotdepass() {     
       if (document.getElementById("passw").value === ''){        
           var messagePassw1 = "<br/>Le champ mot de passe est vide.";         
           message += messagePassw1;         
           document.getElementById("errordiv").innerHTML = message;    
            }//end if 
}//end function 