<!DOCTYPE html>
<html>
<head>
	<title>Options de Payement</title>
	<meta charset="utf-8">
	<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">

	.logo
{
	float: left;
	width: 300px;
}
#admin

{
	position: absolute;
	top:0px;
	right:0px;
	text-align: right;
	font-size:1.5em;
}
#nav

{
color:white;
font-weight:bold;       
font-size:2em;  
text-align: center; 
}

h1
{ 

font-style: bold;
color:#49868F;
 }

 #footer 
{ 

background-color:#49868F;
position: absolute;
font-weight: bold;
bottom:0;
width:100%;
padding-top:40px;
height:50px; 
}

</style>
</head>
<body>
	<h1 class="logo"><img src="logo_ece_amazon1.png" alt="Logo de ECE AMAZON" height=" 150" width="200"></h1>
<div id="colonne2">
    	    <form action="/search" id="searchthis" method="Post">
    	        <input id="search" name="q" type="text" placeholder="" />
    	        <input id="search-btn" type="submit" value="Rechercher" />
    	    </form>
    	</div>
    	<br><br><br><br><br><br><br>

	<div id="nav">      
	  <a href="categories.html">Categories</a>        
	  <a href="ventes_flash.php">Ventes<i>Flash</i></a>        
	  <a href="vendeur.php">Vendre</a>       
	  <a href="votre_compte.php">Votre Compte</a>
	  <a href="panier.html"><img src="panier.png" height=" 50" width="50"></a>  
	  <a href="aide.html">Aide</a>

	   </div> 
	    <div id="admin"><a href="admin.html"> Administration </a>
	   </div>


<!-- Texte -->
	   <h1> Options de Paiement </h1>

<p> En plus des cartes bancaires ( MasterCard, American Express, Paypal) , vous pouvez également régler par chèque-cadeau!</p>

<br><br>
<p style="color:red";><b> ATTENTION!</b></p>
	<p> Suite à de nombreux chèques impayés, la direction refuse ce moyen de payement <p>



	   <!-- Footer -->
<div id="footer">Copyright &copy; 2019 ECE Amazon<br>   
 <a href="mailto:ece_amazon_contact@gmail.com">ece_amazon_contact@gmail.com </a> 
</div> 

</body>
</html>