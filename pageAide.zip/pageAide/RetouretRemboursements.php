<!DOCTYPE html>
<html>
<head>
	<title>Retour et Remboursements</title>
	<meta charset="utf-8">

<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">

	.logo
{
	float: left;
	width: 300px;
}
#admin

{
	position: absolute;
	top:0px;
	right:0px;
	text-align: right;
	font-size:1.5em;
}
#nav

{
color:white;
font-weight:bold;       
font-size:2em;  
text-align: center; 
}

h1
{ 

font-style: bold;
color:#49868F;
 }

 h2
 {
 	color:#49868F; 
 }
 #footer 
{ 

background-color:#49868F;
font-weight: bold;
bottom:0;
width:100%;
padding-top:40px;
height:50px; 
}

</style>
</head>
<body>


	<h1 class="logo"><img src="logo_ece_amazon1.png" alt="Logo de ECE AMAZON" height=" 150" width="200"></h1>
<div id="colonne2">
    	    <form action="/search" id="searchthis" method="Post">
    	        <input id="search" name="q" type="text" placeholder="" />
    	        <input id="search-btn" type="submit" value="Rechercher" />
    	    </form>
    	</div>
    	<br><br><br><br><br><br><br>

	<div id="nav">      
	  <a href="categories.html">Categories</a>        
	  <a href="ventes_flash.php">Ventes<i>Flash</i></a>        
	  <a href="vendeur.php">Vendre</a>       
	  <a href="votre_compte.php">Votre Compte</a>
	  <a href="panier.html"><img src="panier.png" height=" 50" width="50"></a>  
	  <a href="aide.html">Aide</a>
	   </div> 
	    <div id="admin"><a href="admin.html"> Administration </a>
	   </div>

	 

<!-- Texte -->
<h1> Retour et remboursements <h1>

<h2> Retours </h2>
<p> Les retours sont <b>gratuits</b> durant 30 jours pour tout les articles vendus sur notre site sous réserve de leur bon état au moment de la réexpédition.<p>
	<br>

<h2> Remboursements</h2>
<p> Les remboursements sont possibles sous présentation du ticket de caisse.</p>


<!-- Footer -->
<div id="footer">Copyright &copy; 2019 ECE Amazon<br>   
 <a href="mailto:ece_amazon_contact@gmail.com">ece_amazon_contact@gmail.com </a> 
</div> 

</body>