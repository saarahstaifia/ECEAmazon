<!DOCTYPE html>
<html>
<head>
	<title> ECE AMAZON</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="designaccueil.css" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Defilement automatique des images pour livre-->
<script type="text/javascript" >
$(document).ready(function(){
var $livres = $('#livres');
var $img = $('#livres img');
var $indexImg = $img.length - 1;
var i = 0; //compteur
var $currentImg = $img.eq(i); //image courante
$img.css('display', 'none');
$currentImg.css('display', 'block');
//quand on clique sur le bouton "suivant"
$('.next').click(function(){
i++;
if (i <= $indexImg){
$img.css('display', 'none');
$currentImg = $img.eq(i);
$currentImg.css('display', 'block');
} else {
i = $indexImg;
}
});

//defilement automatique
function slideImg(){
setTimeout(function() {
if (i < $indexImg) {
i++;
} else {
i = 0;
}
$img.css('display', 'none');
$currentImg = $img.eq(i);
$currentImg.css('display', 'block');
slideImg();
}, 4000);
}
slideImg();
});
</script>

<!-- Defilement automatique des images pour musique -->
<script type="text/javascript" >
$(document).ready(function(){
var $livres = $('#musique');
var $img = $('#musique img');
var $indexImg = $img.length - 1;
var i = 0; //compteur
var $currentImg = $img.eq(i); //image courante
$img.css('display', 'none');
$currentImg.css('display', 'block');
//quand on clique sur le bouton "suivant"
$('.next').click(function(){
i++;
if (i <= $indexImg){
$img.css('display', 'none');
$currentImg = $img.eq(i);
$currentImg.css('display', 'block');
} else {
i = $indexImg;
}
});

//defilement automatique
function slideImg(){
setTimeout(function() {
if (i < $indexImg) {
i++;
} else {
i = 0;
}
$img.css('display', 'none');
$currentImg = $img.eq(i);
$currentImg.css('display', 'block');
slideImg();
}, 4000);
}
slideImg();
});
</script>
<!-- Defilement automatique des images pour vetements -->
<script type="text/javascript" >
$(document).ready(function(){
var $livres = $('#vetements');
var $img = $('#vetements img');
var $indexImg = $img.length - 1;
var i = 0; //compteur
var $currentImg = $img.eq(i); //image courante
$img.css('display', 'none');
$currentImg.css('display', 'block');

//defilement automatique
function slideImg(){
setTimeout(function() {
if (i < $indexImg) {
i++;
} else {
i = 0;
}
$img.css('display', 'none');
$currentImg = $img.eq(i);
$currentImg.css('display', 'block');
slideImg();
}, 4000);
}
slideImg();
});
</script>


<!-- Defilement automatique des images pour sports et loisirs -->
<script type="text/javascript" >
$(document).ready(function(){
var $livres = $('#sportsloisirs');
var $img = $('#sportsloisirs img');
var $indexImg = $img.length - 1;
var i = 0; //compteur
var $currentImg = $img.eq(i); //image courante
$img.css('display', 'none');
$currentImg.css('display', 'block');

//defilement automatique
function slideImg(){
setTimeout(function() {
if (i < $indexImg) {
i++;
} else {
i = 0;
}
$img.css('display', 'none');
$currentImg = $img.eq(i);
$currentImg.css('display', 'block');
slideImg();
}, 4000);
}
slideImg();
});
</script>
<!-- fin du script-->
</head>
<body>

<!-- Les différents onglets -->
<h1 class="logo"><img src="logo_ece_amazon1.png" alt="Logo de ECE AMAZON" height=" 150" width="200"></h1>
<div id="colonne2">
    	    <form action="/search" id="searchthis" method="Post">
    	        <input id="search" name="q" type="text" placeholder="" />
    	        <input id="search-btn" type="submit" value="Rechercher" />
    	    </form>
    	</div>

	<br><br><br><br><br><br><br>
	<div id="nav">      
	  <a href="categories.php">Categories</a>        
	  <a href="ventes_flash.php">Ventes<i>Flash</i></a>        
	  <a href="vendeur.php">Vendre</a>       
	  <a href="votre_compte.php">Votre Compte</a>
	  <a href="panier.php"><img src="panier.png" height=" 50" width="50"></a>  
	  <a href="aide.php">Aide</a>
	   </div> 
	 


<!-- Administrateur, accessible en haut à gauche de l'écran -->

	   <div id="admin"><a href="admin.php"> Administration </a>
	   </div>


<!-----------------Livres-------------------------->
<h1><a href="livre.php"> Nos meilleures ventes "Livres"</a></h1>
<div id="livres">
	
<img src="livre1_probabilites.jpg" width="300" height="300">
<img src="livre2_analyse.jpg" width="300" height="300">
<img src="livre3_java.jpg" width="300" height="300">
</div>
<br>
<br>


<!----------------- Musique---------------------------->
<h1><a href="musique.php"> Nos meilleures ventes "Musique"</a></h1>
<div id="musique">

<img src="musique1_relaxation.jpg" width="300" height="300">
<img src="musique2_meditation.jpg" width="300" height="300">
<img src="musique3_rock.jpg" width="300" height="300">
</div>
<br>
<br>

<!----------------Vetements----------------------------->

<h1><a href="vetement.php"> Nos meilleures ventes "Vetements"</a></h1>
<div id="vetements"> 

<img src="vetement1_reveil.jpg" width="300" height="300">
<img src="vetement2_sciences.jpg" width="300" height="300">
<img src="vetement3_engineer.jpg" width="300" height="300">
<br>
<br>

</div>
<!------------------------------ Sports et Loisirs----------->
<h1><a href="sport_loisir.php"> Nos meilleures ventes "Sports et Loisirs"</a></h1>
<div id="sportsloisirs"> 
<img src="loisir1_ski.jpg" width="300" height="300">
<img src="loisir2_espagne.jpg" width="300" height="300">
<br>
<br>


</div>

<!-- Footer -->
<div id="footer">Copyright &copy; 2019 ECE Amazon<br>   
 <a href="mailto:ece_amazon_contact@gmail.com">ece_amazon_contact@gmail.com </a> 
</div> 
</div> 


</body>
</html>
